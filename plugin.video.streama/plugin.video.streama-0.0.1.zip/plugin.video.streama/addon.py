# -*- coding: utf-8 -*-
# Module: default
# Author: joen, bodems
# Created on: 24.08.2017
# License: MIT

from __future__ import print_function

import json
import operator
import routing
import sys
import urllib
from urllib import urlencode
import urllib2
import urlparse
from urlparse import parse_qsl
import cookielib
import xbmcgui
import xbmcplugin
import xbmcaddon
import zipfile
import xbmc
import xbmcvfs
import shutil
import os

addon = xbmcaddon.Addon('plugin.video.streama')
streamaurl = 'http://www.tvnetplay.net:8080'
username = addon.getSetting('username')
password = addon.getSetting('password')
maxval = '20000'

# Initialize the authentication
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
login_data = urllib.urlencode({'username' : username, 'password' : password, 'remember_me' : 'on'})
# Authenticate
opener.open(streamaurl + '/login/authenticate', login_data)

cookiestring = str(cj).split(" ")
sessionid = cookiestring[1].split("JSESSIONID=")
#remember_me = cookiestring[5].split("streama_remember_me=")

try:
    remember_me = cookiestring[5].split("streama_remember_me=")
except Exception:
    advertencia = xbmcgui.Dialog()
    advertencia.ok("Error de Autenticación","No es posible alcalzar el Servidor","Comprobar datos de conexión!")
    sys.exit

VIDEOS = {  'Series': [],
            'Películas': [],
            'Destacadas': [],
            'Acción': [],
            'Aventura': [],
            'Comedia': [],
            'Familia': [],
            'Terror': [],
            'Buscar': [],
            }


# Get the list of Movies from Streama
# movies = opener.open(streamaurl + '/dash/listMovies.json')
# Put the list of movies into the category list
# VIDEOS['Movies'] = json.loads(movies.read())

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Initialize the authentication
cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
login_data = urllib.urlencode({'username' : username, 'password' : password, 'remember_me' : 'on'})
# Authenticate
opener.open(streamaurl + '/login/authenticate', login_data)

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))

def conectando():
    conectado = xbmcgui.Dialog()
    conectado.ok("Se establecio Conexion","Comprobacion OK","Conexión!")

def listar(category, showid, genre):
    # Get the list of videos in the category.
    videos = get_videos(category, showid)
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['title'])
        for film in video['genre']:
            genero = film['name']
            if (genero == genre):
                year = video['release_date']
                list_item.setInfo(
                'video', {'title': video['title'],'plot': video['overview'],
                'genre' : film['name'],'rating': video['vote_average'],'year': video['release_date']
                })
                list_item.setArt({'poster': 'https://image.tmdb.org/t/p/w500//' + video['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + video['backdrop_path']})
                list_item.setProperty('IsPlayable', 'true')
                # Create a URL for a plugin recursive call.
                id = video['id']
                url = get_url(action='play', video=id)
                #Add the list item to a virtual Kodi folder.
                is_folder = False
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
                break

def get_categories():
    # return the list of categories
    return VIDEOS.iterkeys()

def get_videos(category, showid):
    if category == 'Series':
        items = opener.open(streamaurl + '/dash/listShows.json?max=' + maxval)
        videolist = json.loads(items.read())
        return videolist["list"]
    elif category == 'Episodes':
        items = opener.open(streamaurl + '/tvShow/EpisodesForTvShow.json?id=' + showid)
        videolist = json.loads(items.read())
        return videolist
    elif category == 'Películas':
        items = opener.open(streamaurl + '/dash/listMovies.json?max=' + maxval)
        videolist = json.loads(items.read())
        return videolist["list"]
    elif category == 'Generic Videos':
        items = opener.open(streamaurl + '/dash/listGenericVideos.json')
        videolist = json.loads(items.read())
        return videolist["list"]
    elif category == 'Acción':
        items = opener.open(streamaurl + '/dash/listMovies.json?max=' + maxval)
        videolist = json.loads(items.read())
        return videolist["list"]
    elif category == 'Aventura':
        items = opener.open(streamaurl + '/dash/listMovies.json?max=' + maxval)
        videolist = json.loads(items.read())
        return videolist["list"]
    elif category == 'Comedia':
        items = opener.open(streamaurl + '/dash/listMovies.json?max=' + maxval)
        videolist = json.loads(items.read())
        return videolist["list"]
    elif category == 'Familia':
         #items = opener.open(streamaurl + '/dash/listGenres.json')
        items = opener.open(streamaurl + '/dash/listMovies.json?max=' + maxval)
        videolist = json.loads(items.read())
        return videolist["list"]
        #return videolist
    elif category == 'Terror':
        items = opener.open(streamaurl + '/dash/listMovies.json?max=' + maxval)
        videolist = json.loads(items.read())
        return videolist["list"]
    elif category == 'Destacadas':
        items = opener.open(streamaurl + '/dash/listNewReleases.json')
        videolist = json.loads(items.read())
        return videolist
    elif category == 'Buscar':
        dialog = xbmcgui.Dialog()
        searchstring = dialog.input('Buscar:', type=xbmcgui.INPUT_ALPHANUM)
        if len(searchstring) !=0:
            searchstring = urllib.quote_plus(searchstring)
            items = opener.open(streamaurl + '/dash/searchMedia.json?query=' + searchstring)
            videolist = json.loads(items.read())
            return videolist
        else:
            list_categories()
    else:
        items = []
        videolist = json.loads(items.read())
        return videolist


def list_categories():
    # Get video categories
    categories = get_categories()
    
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        listado = list_item.setInfo('video', {'title': category})
        listado = list_item.setArt({'fanart': 'http://tvnetplay.net/kdi/media/fanart-1.jpg'})
        list_item.setInfo('video', {'title': category})
        #if (category == 'Películas'):
        #    list_item.setArt({'thumb': 'http://tvnetplay.net/kdi/folder/star.png'})
        if (category == 'Buscar'):
            list_item.setArt({'thumb': 'http://tvnetplay.net/kdi/folder/0021.png'})
        else:
            list_item.setArt({'thumb': 'http://tvnetplay.net/kdi/folder/star1.png'})
        url = get_url(action='listing', category=category, showid=0)
            # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
            # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.endOfDirectory(_handle)
    

def list_videos(category, showid):
    # Get the list of videos in the category.
    videos = get_videos(category, showid)

    if category == 'Series':
        for video in videos:
            list_item = xbmcgui.ListItem(label=video['name'])
            listado = list_item.setArt({'fanart': 'http://tvnetplay.net/kdi/media/fanart-1.jpg'})
            try:
                list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' + video['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['poster_path']})
                list_item.setInfo('video', {'plot': video['overview']})
            except:
                foo = 23
            id = video['id']
            url = get_url(action='listing', category='Episodes', showid=id)
            is_folder = True
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    elif category == 'Episodes':
        for video in videos:
            list_item = xbmcgui.ListItem(label=video['name'])
            listado = 'https://image.tmdb.org/t/p/w500//' + video['still_path']
            if video['hasFile'] == 1:
                list_item = xbmcgui.ListItem(label='S'+str(video['season_number'])+'E'+str(video['episode_number'])+' '+video['name'])
                list_item.setInfo('video', {'title': 'S'+str(video['season_number'])+'E'+str(video['episode_number'])+' '+video['name'], 'plot': video['overview']})
                list_item.setArt({'poster': listado, 'icon': listado})
                list_item.setProperty('IsPlayable', 'true')
                id = video['id']
                url = get_url(action='play', video=id)
                is_folder = False
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    elif category == 'Películas':
        # Iterate through videos.
        for video in videos:
            # Create a list item with a text label and a thumbnail image.
            list_item = xbmcgui.ListItem(label=video['title'])
            # Set additional info for the list item.
            for film in video['genre']:
                year = video['release_date']
                list_item.setInfo(
                'video', {'title': video['title'],'plot': video['overview'],
                'genre' : film['name'],'rating': video['vote_average'],'year': video['release_date']
                })
            # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
            # Here we use the same image for all items for simplicity's sake.
            # In a real-life plugin you need to set each image accordingly.
            try:
                list_item.setArt({'poster': 'https://image.tmdb.org/t/p/w500//' + video['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + video['backdrop_path']})
            except:
                foo = 23
            # Set 'IsPlayable' property to 'true'.
            list_item.setProperty('IsPlayable', 'true')
            # Create a URL for a plugin recursive call.
            id = video['id']
            url = get_url(action='play', video=id)
            # Add the list item to a virtual Kodi folder.
            is_folder = False
            # Add our item to the Kodi virtual folder listing.
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
            #break

    elif category == 'Generic Videos':
        for video in videos:
            # Create a list item with a text label and a thumbnail image.
            list_item = xbmcgui.ListItem(label=video['title'])
            # Set additional info for the list item.
            list_item.setInfo('video', {'title': video['title'], 'genre': 'Test'})
            list_item.setProperty('IsPlayable', 'true')
            id = video['id']

            url = get_url(action='play', video=id)
            is_folder = False
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    elif category == 'Acción':
        genre = u'Acción'
        listar(category, showid, genre)

    elif category == 'Aventura':
        genre = 'Aventura'
        listar(category, showid, genre)

    elif category == 'Comedia':
        genre = 'Comedia'
        listar(category, showid, genre)
    
    elif category == 'Familia':
        genre = 'Familia'
        listar(category, showid, genre)

    elif category == 'Terror':
        genre = 'Terror'
        listar(category, showid, genre)

    elif category == 'Destacadas':
        for video in videos:
            try:
                list_item = xbmcgui.ListItem(label=video['movie']['title'])
                list_item.setInfo(
                'video', {'title': video['movie']['title'],
                'plot': video['movie']['overview'],
                'rating': video['movie']['vote_average'],
                'year': video['movie']['release_date']}            
                )
                list_item.setArt({'poster': 'https://image.tmdb.org/t/p/w500//' + video['movie']['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['movie']['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + video['movie']['backdrop_path']})
                id = video['movie']['id']
                url = get_url(action='play', video=id)
                is_folder = False
                list_item.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
            except:
                foo = 23
            try:
                list_item = xbmcgui.ListItem(label=video['tvShow']['name'])
                list_item.setInfo(
                'video', {'title': video['tvShow']['name'],
                'plot': video['tvShow']['overview'],
                'rating': video['tvShow']['vote_average']}            
                )
                #list_item.setArt({'poster': 'https://image.tmdb.org/t/p/w500//' + video['tvShow']['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + video['tvShow']['poster_path'], 'fanart': 'https://image.tmdb.org/t/p/w1280//' + video['tvShow']['backdrop_path']})
                list_item.setArt({'poster': 'https://image.tmdb.org/t/p/w500//' + video['tvShow']['poster_path'], 'fanart': 'http://tvnetplay.net/kdi/media/fanart-1.jpg'})
                id = video['tvShow']['id']
                url = get_url(action='listing', category='Episodes', showid=id)
                is_folder = True
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
            except:
                foo = 42

    elif category == 'Buscar':
        if len(videos['shows']) != 0:
            for i in range (0, len(videos['shows'])):
                list_item = xbmcgui.ListItem(label=videos['shows'][i]['name'] + ' - Serie')
                list_item.setArt({'thumb': 'https://image.tmdb.org/t/p/w500//' + videos['shows'][i]['poster_path'], 'icon': 'https://image.tmdb.org/t/p/w500//' + videos['shows'][i]['poster_path']})
                id = videos['shows'][i]['id']
                url = get_url(action='listing', category='Episodes', showid=id)
                is_folder = True
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
        if len(videos['movies']) !=0:
            for i in range (0, len(videos['movies'])):
                list_item = xbmcgui.ListItem(label=videos['movies'][i]['title'])
                list_item.setInfo(
                'video', {'title': videos['movies'][i]['title'],
                'plot': videos['movies'][i]['overview'],
                'rating': videos['movies'][i]['vote_average']}            
                )
                list_item.setArt({'poster': 'https://image.tmdb.org/t/p/w500//' + videos['movies'][i]['poster_path']})
                #list_item.setProperty('IsPlayable', 'true')
                id = videos['movies'][i]['id']
                url = get_url(action='play', video=id)
                is_folder = False                
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
                 
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def play_video(id):
    # Get the JSON for the corresponding video from Streama
    movie = opener.open(streamaurl + '/video/show.json?id=' + id)
    # Create the path from resulting info
    movie_json = json.loads(movie.read())
    path = streamaurl + movie_json['files'][0]['src']

    # if path contains streamaurl, append sessionid-cookie and remember_me-cookie for auth
    if path.find(streamaurl) != -1:
        path = path + '|Cookie=JSESSIONID%3D' + sessionid[1] + '%3Bstreama_remember_me%3D' + remember_me[1] + '%3B'
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'], params['showid'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()

def conectu1():
    
    destacadasDATA = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts/destacadas.DATA.xml')
    skinshortcuts = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts/')
    IncludeDef = xbmc.translatePath('special://home/addons/skin.arctic.zephyr/1080i/Includes_Defs.xml')
    DialogVideoInfo = xbmc.translatePath('special://home/addons/skin.arctic.zephyr/1080i/DialogVideoInfo.xml')
    #Elimina el regsitro userdata/addon_data/script.skinshortcuts/
    if xbmcvfs.exists(destacadasDATA):
        sys.exit
    else:
        #Elimina carpeta anterior en ruta userdata/addon_data/script.skinshortcuts/
        shutil.rmtree(skinshortcuts, ignore_errors=True)
        #shutil.rmtree(IncludeDef, ignore_errors=True)
        os.remove(IncludeDef)
        os.remove(DialogVideoInfo)
        #os.remove(DialogVideoInfo)

        # Rutas ---
        SrcSkinshortcuts = xbmc.translatePath('special://home/addons/plugin.video.streama/menu/script.skinshortcuts')
        SrcIncludeDef = xbmc.translatePath('special://home/addons/plugin.video.streama/menu/Includes_Defs.xml')
        SrcDialogVideoInfo = xbmc.translatePath('special://home/addons/plugin.video.streama/menu/DialogVideoInfo.xml')
        # Destinos ---
        DstSkinshortcuts = xbmc.translatePath('special://home/userdata/addon_data/script.skinshortcuts')
        DstIncludeDef = xbmc.translatePath('special://home/addons/skin.arctic.zephyr/1080i/Includes_Defs.xml')
        DstDialogVideoInfo = xbmc.translatePath('special://home/addons/skin.arctic.zephyr/1080i/DialogVideoInfo.xml')
        # Copiar Archivos ----
        shutil.copytree(SrcSkinshortcuts, DstSkinshortcuts, symlinks=False, ignore=None)
        shutil.copy(SrcIncludeDef, DstIncludeDef)
        shutil.copy(SrcDialogVideoInfo, DstDialogVideoInfo)
        #os.remove(IncludeDef)
        #Descomprime Actualizacion de script.skinshortcuts en /userdata/addon_data/
        #targetzipA = xbmc.translatePath('special://home/addons/plugin.video.streama/menu/script.skinshortcuts.zip')
        #extracttoA = xbmc.translatePath('special://home/userdata/addon_data/')
        #with zipfile.ZipFile(targetzipA) as zf:
        #    zf.extractall(extracttoA)
        
        #Descomprime Actualizacion de Settings en /addons/resource.uisounds.fromashes.zip
        #targetzipB = xbmc.translatePath('special://home/addons/plugin.video.streama/menu/Includes_Defs.zip')
        #extracttoB = xbmc.translatePath('special://home/addons/skin.arctic.zephyr/1080i/')
        #with zipfile.ZipFile(targetzipB) as zf:
        #    zf.extractall(extracttoB)

if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    try:
        router(sys.argv[2][1:])
        conectu1()
    except Exception:
        sys.exit